@extends('layout')

@section('content')
    <table class="table">
        <thead>
            <tr>
                <th>id</th>
                <th>name</th>
                <th>action</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($books as $book)
                <tr>
                    <td>{{$book->id}}</td>
                    <td>{{$book->name}}</td>
                    <td><a href="{{ route('book.detail', ['id'=>$book->id]) }}" class="btn btn-sm btn-outline-dark">detail</a></td>
                </tr>
            @empty
                <tr><td colspan="3">Data tidak ditemukan</td></tr>
            @endforelse    
        </tbody>
    </table>
    {{$books->links()}}
@endsection