@extends('layout')

@section('content')
    <table class="table table-hover">
        <thead>
            <tr>
                <th>nim</th>
                <th>nama</th>
                <th>prodi</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($students as $student)
                <tr>
                    <td>{{$student['nim']}}</td>
                    <td>{{$student['nama']}}</td>
                    <td>{{$student['prodi']}}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
@endsection