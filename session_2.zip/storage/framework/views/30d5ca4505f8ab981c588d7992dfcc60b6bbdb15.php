

<?php $__env->startSection('content'); ?>
    <table class="table">
        <thead>
            <tr>
                <th>id</th>
                <th>name</th>
                <th>action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($book->id); ?></td>
                    <td><?php echo e($book->name); ?></td>
                    <td><a href="<?php echo e(route('book.detail', ['id'=>$book->id])); ?>" class="btn btn-sm btn-outline-dark">detail</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="3">Data tidak ditemukan</td></tr>
            <?php endif; ?>    
        </tbody>
    </table>
    <?php echo e($books->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\apps\php\ngajar\session_2\resources\views/book/list.blade.php ENDPATH**/ ?>