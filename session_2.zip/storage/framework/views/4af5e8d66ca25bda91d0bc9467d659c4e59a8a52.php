

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-4">
            <img src="<?php echo e(asset('cover/'.$book->photo)); ?>" alt="">
        </div>
        <div class="col-8">
            <h4><?php echo e($book->name); ?></h4>
            <h5><?php echo e($book->genre->name); ?></h5>
            <h6><i><?php echo e($book->publish_date->format('d F Y')); ?></i></h6>
            <p><?php echo e($book->description); ?></p>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\apps\php\ngajar\session_2\resources\views/book/detail.blade.php ENDPATH**/ ?>