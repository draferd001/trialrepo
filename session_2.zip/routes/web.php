<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\BookController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
return view('layout');
});

Route::get('student_list',[StudentController::class,'index']);

Route::get('student_detail/finance',function(){
    echo '<h1>FINANCE PAGE</h1>';
});

Route::get('student_detail/{name}/{class?}',[StudentController::class,'detail']);

Route::get('book_list',[BookController::class,'showList']);
Route::get('book_detail/{id}',[BookController::class,'showDetail'])->name('book.detail');
//Route::<http_method>(url,callback);