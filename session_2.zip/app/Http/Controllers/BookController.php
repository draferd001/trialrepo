<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Book;

class BookController extends Controller
{
    //menampilkan daftar buku
    public function showList(){
        //1. mengambil data dari DB
            //eloquent
            //select * from books setiap 2 data
            $books = Book::paginate(2);

        //2. passing ke view
        return view('book.list',['books'=>$books]);
    }

    //menampilkan detail buku
    public function showDetail($id){
            $book =  Book::find($id);
            //Book::where('id','=',$id);

            return view('book.detail',['book'=>$book]);
    }
}
