<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class StudentController extends Controller
{
    //
    public function index(){
        $students = [
            [
                'nim'=> '2500001',
                'nama'=> 'Jason Patrick',
                'prodi' => 'Teknik Informatika'
            ],
            [
                'nim'=> '2500002',
                'nama'=> 'Hendri Setiadi',
                'prodi' => 'Teknik Informatika'
            ],
            [
                'nim'=> '2500003',
                'nama'=> 'Angelina',
                'prodi' => 'Sistem Informasi'
            ],
        ];
    
        $datas =  [
            'students'=>$students,
            'variable_2'=>'ini var 2'
        ];
    
        return view('student.list',$datas);
    }

    public function detail($name,$class='tanpa kelas'){
        echo '<h1>WELCOME '.$name.'</h1>';
        echo '<h1>Kelas :'.$class.'</h1>';
    }
}
