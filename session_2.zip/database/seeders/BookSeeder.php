<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class BookSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        $books = [
            [
                'name'=>'Azab Mahasiswa Menyontek',
                'photo'=>'1.jpg',
                'description'=>'Description satu',
                'genre_id'=>3,
                'publish_date'=>'2024-03-01',
            ],
            [
                'name'=>'TEMPO : Prediksi Lebaran 2024',
                'photo'=>'1.jpg',
                'description'=>'Description dua',
                'publish_date'=>'2024-03-01',
                'genre_id'=>2
            ],
            [
                'name'=>'Doraemon',
                'photo'=>'1.jpg',
                'description'=>'Description tiga',
                'genre_id'=>1,
                'publish_date'=>'2024-03-01',
            ],
        ];
        DB::table('books')->insert($books);
    }
}
